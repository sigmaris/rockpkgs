#define __CLC_FUNCTION atom_xor
#include <clc/atom_decl_int64.inc>
