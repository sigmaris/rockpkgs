#define __CLC_FUNCTION atom_sub
#define __CLC_ADDRESS_SPACE global
#include <clc/atom_decl_int32.inc>
