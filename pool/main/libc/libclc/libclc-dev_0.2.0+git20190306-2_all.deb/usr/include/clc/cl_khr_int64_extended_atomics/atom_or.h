#define __CLC_FUNCTION atom_or
#include <clc/atom_decl_int64.inc>
