_CLC_DECL void mem_fence(cl_mem_fence_flags flags);
_CLC_DECL void read_mem_fence(cl_mem_fence_flags flags);
_CLC_DECL void write_mem_fence(cl_mem_fence_flags flags);
