#define mad_hi(a, b, c) (mul_hi((a),(b))+(c))
