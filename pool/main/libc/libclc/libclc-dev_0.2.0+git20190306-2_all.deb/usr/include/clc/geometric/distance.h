#define __CLC_BODY <clc/geometric/distance.inc>
#include <clc/geometric/floatn.inc>
