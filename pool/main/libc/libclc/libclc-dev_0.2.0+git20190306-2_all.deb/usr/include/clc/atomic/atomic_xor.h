#define __CLC_FUNCTION atomic_xor
#include <clc/atomic/atomic_decl.inc>
