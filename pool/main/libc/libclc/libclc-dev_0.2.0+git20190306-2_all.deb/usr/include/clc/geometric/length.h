#define __CLC_BODY <clc/geometric/length.inc>
#include <clc/geometric/floatn.inc>
