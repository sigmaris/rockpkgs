#define __CLC_FUNCTION atom_and
#include <clc/atom_decl_int64.inc>
