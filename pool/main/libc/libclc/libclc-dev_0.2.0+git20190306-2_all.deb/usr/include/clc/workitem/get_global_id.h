_CLC_DECL size_t get_global_id(uint dim);
