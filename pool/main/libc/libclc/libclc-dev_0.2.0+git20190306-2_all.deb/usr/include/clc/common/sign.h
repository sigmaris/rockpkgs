#define __CLC_FUNCTION sign
#define __CLC_BODY <clc/math/unary_decl.inc>
#include <clc/math/gentype.inc>
#undef __CLC_FUNCTION
#undef __CLC_BODY
