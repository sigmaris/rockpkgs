#define __CLC_BODY <clc/math/lgamma_r.inc>
#include <clc/math/gentype.inc>
