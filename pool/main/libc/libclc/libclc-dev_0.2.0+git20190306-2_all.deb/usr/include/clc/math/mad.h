#define __CLC_BODY <clc/math/mad.inc>
#include <clc/math/gentype.inc>
